const express = require('express');
const mongoose = require('mongoose');
const fs = require('fs');
const pdfParse = require('pdf-parse');

const app = express();
app.use(express.json());


mongoose.connect('mongodb://localhost:27017/myDatabase', { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => console.log('Connected to MongoDB'))
    .catch((err) => console.error('MongoDB connection error:', err));


const PdfDataSchema = new mongoose.Schema({
    content: String,
});
const PdfData = mongoose.model('PdfData', PdfDataSchema);


app.post('/upload-pdf', async (req, res) => {
    try {
        const pdfPath = 'C:\\Users\\Asus\\Desktop\\CO\\New folder\\my project\\case_final_dataset.pdf';
        const pdfBuffer = fs.readFileSync(pdfPath);

        const data = await pdfParse(pdfBuffer);
        const pdfData = new PdfData({ content: data.text });

        await pdfData.save();
        res.status(200).send('PDF data saved to MongoDB!');
    } catch (error) {
        console.error('Error uploading PDF:', error);
        res.status(500).send('Failed to upload PDF');
    }
});

// Run the server
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
app.post('/upload-pdf', async (req, res) => {
    try {
        
        const pdfPath = "C:\\Users\\Asus\\Desktop\\CO\\New folder\\my project\\case_final_dataset.pdf";

  
        const pdfBuffer = fs.readFileSync(pdfPath);

  
        const data = await pdfParse(pdfBuffer);

        const pdfData = new PdfData({ content: data.text });
        await pdfData.save();

        
        res.status(200).send("PDF data saved to MongoDB!");
    } catch (error) {
        console.error("Error uploading PDF:", error);
        res.status(500).send("Failed to upload PDF");
    }
});